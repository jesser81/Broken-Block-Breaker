﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Block_Breaker
{
    public class Ball : MonoBehaviour
    {
        // Variables - Define Ball
        public static Ball instance;
        
        public float bSpeed;
        private Vector3 paddleToBallVector;
        private Rigidbody2D rb2D;
        private bool hasStarted = false;
        private PaddleController paddle;
        //private GameObject bSpawn;

        void Awake()
        {
            rb2D = GetComponent<Rigidbody2D>();
            paddle = GameObject.FindObjectOfType<PaddleController>();
            //bSpawn = GameObject.FindGameObjectWithTag("BallSpawn");
        }

        // Use this for initialization
        void Start()
        {
            paddleToBallVector = this.transform.position - paddle.transform.position;

        }

        // Update is called once per frame
        void FixedUpdate()
        {
            
            LaunchBall();
        }

        

        void LaunchBall()
        {
            if (!hasStarted)
            {
                this.transform.position = paddle.transform.position + paddleToBallVector;
                
                    if (Input.GetMouseButton(0))
                    {
                        hasStarted = true;
                        rb2D.velocity = new Vector2(0, bSpeed);
                    }
            }
            
            
        }
    }
}
