﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Block_Breaker
{
    public class Brick : MonoBehaviour
    {
        // Variables - Define Bricks
        public int maxHits;
        public LevelManager lManager;

        private int timesHit;
        private int brickPoints;
        private int bricksInScene = 1;

        private void Awake()
        {
            
        }

        // Use this for initialization
        void Start()
        {
            timesHit = 0;
            brickPoints = 0;
        }

        void Update()
        {
            
        }

        void OnCollisionEnter2D(Collision2D coll)
        {
            timesHit++;
            print(timesHit);
            SimulateWin();

            if (timesHit == maxHits || timesHit > maxHits)
            {
                
                Destroy(gameObject);
                bricksInScene--;
                print(bricksInScene);
                brickPoints += brickPoints;
                print(brickPoints);
               
            }
        }

        void SimulateWin()
        {
            lManager.LoadNextLevel();
        }
    }
}
