﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

namespace Block_Breaker
{
    public class LevelManager : MonoBehaviour
    {

        public void OnClickLoadLevel(string name)
        {
            SceneManager.LoadScene(name);
        }

        public void QuitOnClick()
        {
            Application.Quit();
        }

        public void LoadNextLevel()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }

}