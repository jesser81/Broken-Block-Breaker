﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

namespace Block_Breaker
{
    public class LoseCollider : MonoBehaviour
    {
        // Variables 
        //private Text livesText;

        private int lives;

        private void Awake()
        {
            //livesText = GameObject.FindObjectOfType<Text>();
        }

        void Start()
        {
            lives = 1;
        }

        void OnTriggerEnter2D(Collider2D coll)
        {
            lives--;
            //livesText.text = "Lives: " + lives.ToString();
            //print(lives);
            Destroy(coll.gameObject);

            if (lives < 0 || lives == 0)
            {
                SceneManager.LoadScene("Lose");
            }
            //print("Trigger");
        }
    }
}
