﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Block_Breaker
{
    public class SoundManager : MonoBehaviour
    {
        // Variables - Define Sound Manager
        public static SoundManager  instance = null;

        void Awake()
        {
            if (instance != null)
            {
                Destroy(gameObject);
                Debug.Log("Duplicate Music Player Destroying Self");
            }
            else
            { 
                instance = this;
                DontDestroyOnLoad(this);
            }
        }

        // Use this for initialization
        void Start()
        {
            
        }
        
    }
}
